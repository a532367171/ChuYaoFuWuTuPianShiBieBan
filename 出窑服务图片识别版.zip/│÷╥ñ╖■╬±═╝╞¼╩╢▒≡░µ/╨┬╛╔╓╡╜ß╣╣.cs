﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 出窑服务图片识别版
{
   public struct 新旧值结构
    {
       public string old_value;
       public string new_value;
       public string middle_value;
    };
}
